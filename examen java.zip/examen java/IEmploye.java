public interface IEmploye {
    public String affiche();
    public String compare();
}
